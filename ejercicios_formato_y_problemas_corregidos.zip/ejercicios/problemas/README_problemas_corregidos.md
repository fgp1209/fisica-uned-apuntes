# Problemas corregidos — Mecánica Teórica T0-T1

Corrección aplicada al lote original:

- fórmulas convertidas a formato móvil legible;
- `formula` pasa a aceptar listas de líneas;
- se evita `sqrt(...)`, `y_prime`, `theta_dot` y notación cruda;
- step 0 conservado limpio: enunciado, pizarra vacía, TTS del enunciado;
- problema de Beltrami reestructurado para que cada paso tenga una sola operación cognitiva;
- JSON validado.

Requiere actualizar `ejercicios/app.js` y `ejercicios/app.css` con el parche de formato si se usan fórmulas en lista.
